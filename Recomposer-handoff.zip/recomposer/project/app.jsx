/* ===================== App root ===================== */
const { useState:aS, useRef:aR, useEffect:aE, useMemo:aM, useCallback:aC } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "accent": "indigo",
  "density": "dense",
  "scriptSize": 15,
  "uiFont": "Public Sans"
}/*EDITMODE-END*/;

const FONT_STACKS = {
  "Public Sans": "\"Public Sans\", ui-sans-serif, system-ui, sans-serif",
  "System": "ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif",
};

/* render simulation stages */
function buildStages(cfg){
  const dub = cfg.lang!=="none" && cfg.dub;
  const s = [
    { to:14,  label:"Conforming clips" },
    { to:30,  label:"Applying levels & fades" },
    { to:46,  label:"Mixing music bed (ducking)" },
  ];
  if(dub) s.push({ to:64, label:"Translating & cloning voices" });
  s.push({ to: cfg.format==="video"?86:80, label: cfg.format==="video"?"Rendering video frames":"Bouncing stereo mix" });
  s.push({ to:94, label:"Mastering to "+cfg.loudness+" LUFS" });
  s.push({ to:100, label:"Encoding "+(cfg.format==="video"?"H.264":"WAV") });
  return s;
}

function App(){
  const [t, setT] = useTweaks(TWEAK_DEFAULTS);
  const theme = t.theme, accent = t.accent, density = t.density;

  /* reflect theme tokens on <html> */
  aE(()=>{
    const r = document.documentElement;
    r.setAttribute("data-theme", theme);
    r.setAttribute("data-accent", accent);
    r.setAttribute("data-density", density==="comfortable"?"comfortable":"dense");
    r.style.setProperty("--script-fs", t.scriptSize+"px");
    r.style.setProperty("--font", FONT_STACKS[t.uiFont]||FONT_STACKS["Public Sans"]);
  },[theme,accent,density,t.scriptSize,t.uiFont]);

  /* ---- composition state ---- */
  const [cuts, setCuts] = aS(()=>RC.CUTS.map(c=>({...c})));
  const [bed, setBed] = aS({...RC.BEDS[0]});
  const [overlays] = aS(RC.OVERLAYS);
  const { items, total } = aM(()=>RC.compTimeline(cuts), [cuts]);

  const [selectedId, setSelectedId] = aS("c1");
  const [rightTab, setRightTab] = aS("inspect");
  const [tlCollapsed, setTlCollapsed] = aS(false);

  /* ---- transport ---- */
  const [time, setTime] = aS(()=>{ const v = +localStorage.getItem("rc.t"); return isFinite(v)?v:0; });
  const [playing, setPlaying] = aS(false);
  const [speed, setSpeed] = aS(1);
  const [vol, setVol] = aS(80);
  const [loop, setLoop] = aS(false);
  const timeRef = aR(time); timeRef.current = time;
  const totalRef = aR(total); totalRef.current = total;
  const seek = aC((v)=>{ const nv = Math.max(0, Math.min(totalRef.current, v)); setTime(nv); localStorage.setItem("rc.t", nv); },[]);

  /* rAF engine */
  aE(()=>{
    if(!playing) return;
    let raf, last = performance.now();
    const tick = (now)=>{
      const dt = (now-last)/1000; last = now;
      let nt = timeRef.current + dt*speed;
      if(nt >= totalRef.current){
        if(loop){ nt = 0; }
        else { nt = totalRef.current; setPlaying(false); setTime(nt); return; }
      }
      timeRef.current = nt; setTime(nt);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return ()=>cancelAnimationFrame(raf);
  },[playing, speed, loop]);

  aE(()=>{ if(!playing) localStorage.setItem("rc.t", time); },[playing]); // eslint-disable-line

  /* auto-select active cut while playing */
  const activeCut = aM(()=>items.find(c=>time>=c.start && time<c.end) || (time>=total?items[items.length-1]:items[0]), [items,time,total]);
  aE(()=>{ if(playing && activeCut && activeCut.id!==selectedId) setSelectedId(activeCut.id); },[activeCut,playing]); // eslint-disable-line
  const selCut = aM(()=>{ const i = items.findIndex(c=>c.id===selectedId); return i<0?null:{cut:items[i], idx:i}; },[items,selectedId]);

  /* ---- mutations ---- */
  const patchCut = aC((id,p)=>setCuts(cs=>cs.map(c=>c.id===id?{...c,...p}:c)),[]);
  const removeCut = aC((id)=>setCuts(cs=>{
    const i = cs.findIndex(c=>c.id===id); if(i<0||cs.length<=1) return cs;
    const nc = cs.filter(c=>c.id!==id);
    if(i>0 && nc[nc.length-1].id===nc[i-1]?.id){} // noop guard
    nc[nc.length-1] = {...nc[nc.length-1]}; // ensure last has end handled below
    return nc;
  }),[]);
  /* keep last clip's trans = end */
  aE(()=>{ setCuts(cs=>{ if(!cs.length) return cs; const last=cs[cs.length-1]; if(last.trans.type!=="end"){ const n=[...cs]; n[n.length-1]={...last,trans:{type:"end",dur:0}}; return n; } return cs; }); },[cuts.length]);

  const reorder = aC((from,to)=>setCuts(cs=>{ const n=[...cs]; const [m]=n.splice(from,1); n.splice(to,0,m); return n; }),[]);

  const insertAfter = aC((i, srcClip)=>{
    setCuts(cs=>{
      const base = srcClip || RC.SOURCE_CLIPS[Math.floor(Math.random()*RC.SOURCE_CLIPS.length)];
      const sp = base.spk;
      const nid = "n"+Date.now();
      const newCut = { id:nid, spk:sp, srcIn: 30+Math.random()*200, dur: base.dur, gain:0, fadeIn:0, fadeOut:0,
        text: base.text, trans:{type:"cut",dur:0}, _new:true };
      const n = [...cs]; n.splice(i+1, 0, newCut);
      setTimeout(()=>setSelectedId(nid),0);
      return n;
    });
  },[]);
  const addSource = aC((clip)=>{
    const at = selCut? selCut.idx : cuts.length-1;
    insertAfter(at, clip);
  },[selCut, cuts.length, insertAfter]);

  /* ---- export ---- */
  const [exportCfg, setExportCfg] = aS({ format:"video", quality:"1080", loudness:"-14", captions:false, lang:"none", dub:false });
  const [render, setRender] = aS({ state:"idle", pct:0, stage:"", log:[] });
  const renderRef = aR(null);
  const onExport = aC((action)=>{
    if(action==="reset"){ if(renderRef.current) clearInterval(renderRef.current); setRender({state:"idle",pct:0,stage:"",log:[]}); return; }
    if(action==="start"){
      const stages = buildStages(exportCfg);
      let pct = 0, si = 0, log = [];
      setRender({ state:"rendering", pct:0, stage:stages[0].label, log:[] });
      renderRef.current = setInterval(()=>{
        pct = Math.min(100, pct + (2 + Math.random()*5));
        // advance stage
        while(si < stages.length-1 && pct >= stages[si].to){ log = [...log, stages[si].label+" \u2014 done"]; si++; }
        if(pct>=100){
          clearInterval(renderRef.current);
          log = [...log, stages[stages.length-1].label+" \u2014 done"];
          setRender({ state:"done", pct:100, stage:"Done", log });
        } else {
          setRender({ state:"rendering", pct:Math.round(pct), stage:stages[si].label, log:[...log] });
        }
      }, 130);
    }
  },[exportCfg]);
  aE(()=>()=>{ if(renderRef.current) clearInterval(renderRef.current); },[]);

  const goExport = ()=>{ setRightTab("export"); };

  /* ---- keyboard ---- */
  aE(()=>{
    const onKey = (e)=>{
      const tag = (e.target.tagName||"").toLowerCase();
      if(tag==="input"||tag==="textarea"||tag==="select") return;
      if(e.code==="Space"){ e.preventDefault(); setPlaying(p=>!p); }
      else if(e.key==="j"||e.key==="J"){ seek(timeRef.current-5); }
      else if(e.key==="l"||e.key==="L"){ seek(timeRef.current+5); }
      else if(e.key==="Home"){ seek(0); }
      else if(e.key==="End"){ seek(totalRef.current); }
      else if(e.key==="ArrowLeft"){ e.preventDefault(); seek(timeRef.current-1); }
      else if(e.key==="ArrowRight"){ e.preventDefault(); seek(timeRef.current+1); }
    };
    window.addEventListener("keydown", onKey);
    return ()=>window.removeEventListener("keydown", onKey);
  },[seek]);

  const { LeftRail, SourcePanel, RightPanel } = window.Panels;
  const { Player, Script, Timeline } = window.Studio;

  return (
    <div style={{ height:"100%", display:"flex", flexDirection:"column", background:"var(--bg)" }}>
      {/* ===== Top bar ===== */}
      <div style={{ height:48, flexShrink:0, borderBottom:"1px solid var(--line)", background:"var(--bg-1)",
        display:"flex", alignItems:"center", padding:"0 14px", gap:12, zIndex:40 }}>
        <div style={{ display:"flex", alignItems:"center", gap:7, minWidth:0 }}>
          <span style={{ fontSize:12.5, color:"var(--text-2)", fontWeight:500 }}>Projects</span>
          <I.chevR size={13} style={{ color:"var(--text-3)" }} />
          <span style={{ fontSize:12.5, color:"var(--text-2)", fontWeight:500 }}>Q3 Brand Film</span>
          <I.chevR size={13} style={{ color:"var(--text-3)" }} />
          <span style={{ fontSize:13, color:"var(--text)", fontWeight:650 }}>Recomposition v4</span>
          <Badge tone="mono" style={{ marginLeft:4 }}><span style={{ width:5,height:5,borderRadius:99,background:"var(--src-fx)" }} /> Saved</Badge>
        </div>
        <div style={{ flex:1 }} />
        <div style={{ display:"flex", alignItems:"center", gap:2 }}>
          <Tooltip label="Undo" kbd="\u2318Z"><Btn size="icon" kind="ghost"><I.undo size={16} /></Btn></Tooltip>
          <Tooltip label="Redo" kbd="\u2318\u21e7Z"><Btn size="icon" kind="ghost"><I.redo size={16} /></Btn></Tooltip>
        </div>
        <div style={{ width:1, height:20, background:"var(--line)" }} />
        {/* collaborators */}
        <div style={{ display:"flex", alignItems:"center" }}>
          {["maya","priya","daniel"].map((id,i)=>(
            <span key={id} style={{ marginLeft: i?-7:0, position:"relative", zIndex:3-i }}><Avatar id={id} size={26} ring /></span>
          ))}
        </div>
        <Btn kind="outline" size="md" icon={I.share}>Share</Btn>
        <Btn kind="primary" size="md" icon={I.download} onClick={goExport}>Export</Btn>
      </div>

      {/* ===== Body ===== */}
      <div style={{ flex:1, display:"flex", minHeight:0 }}>
        <LeftRail theme={theme} accent={accent} nav="studio" onNav={()=>{}}
          onToggleTheme={()=>setT("theme", theme==="dark"?"light":"dark")} />
        <SourcePanel onAdd={addSource} />

        {/* center column */}
        <div style={{ flex:1, minWidth:0, display:"flex", flexDirection:"column" }}>
          <Player t={time} total={total} playing={playing} onPlay={()=>setPlaying(p=>!p)} onSeek={seek}
            items={items} activeCut={activeCut} speed={speed} onSpeed={setSpeed} vol={vol} onVol={setVol}
            loop={loop} onLoop={setLoop} />
          <Script items={items} total={total} t={time} selectedId={selectedId}
            onSelect={(id)=>{ setSelectedId(id); setRightTab("inspect"); }}
            onSeek={(v)=>{ seek(v); }} onPatch={patchCut} onRemove={removeCut}
            onReorder={reorder} onInsertAfter={(i)=>insertAfter(i)} />
          <Timeline items={items} total={total} t={time} selectedId={selectedId}
            onSelect={(id)=>{ setSelectedId(id); setRightTab("inspect"); }} onSeek={seek}
            bed={bed} overlays={overlays} collapsed={tlCollapsed} onCollapse={setTlCollapsed} />
        </div>

        <RightPanel tab={rightTab} setTab={setRightTab}
          cut={selCut?.cut} idx={selCut?.idx} total={total}
          onPatch={(p)=>selCut && patchCut(selCut.cut.id, p)} onRemove={()=>selCut && removeCut(selCut.cut.id)}
          bed={bed} onBedPatch={(p)=>setBed(b=>({...b,...p}))} overlays={overlays}
          exportCfg={exportCfg} setExportCfg={setExportCfg} items={items} render={render} onExport={onExport} />
      </div>

      {/* ===== Tweaks ===== */}
      <TweaksPanel title="Tweaks">
        <TweakSection label="Appearance" />
        <TweakRadio label="Theme" value={theme} options={["dark","light"]} onChange={v=>setT("theme",v)} />
        <TweakRadio label="Accent" value={accent} options={["indigo","cyan"]} onChange={v=>setT("accent",v)} />
        <TweakRadio label="Density" value={density} options={["dense","comfortable"]} onChange={v=>setT("density",v)} />
        <TweakSection label="Typography" />
        <TweakSlider label="Transcript size" value={t.scriptSize} min={13} max={19} step={1} unit="px" onChange={v=>setT("scriptSize",v)} />
        <TweakSelect label="UI font" value={t.uiFont} options={["Public Sans","System"]} onChange={v=>setT("uiFont",v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
