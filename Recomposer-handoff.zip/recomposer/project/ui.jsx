/* ===================== Shared UI primitives ===================== */
const { useState, useRef, useEffect, useLayoutEffect, useCallback } = React;

/* ---- Tooltip ---- */
function Tooltip({ label, side="bottom", children, kbd }){
  const [show, setShow] = useState(false);
  const pos = {
    bottom:{ top:"calc(100% + 7px)", left:"50%", transform:"translateX(-50%)" },
    top:{ bottom:"calc(100% + 7px)", left:"50%", transform:"translateX(-50%)" },
    right:{ left:"calc(100% + 7px)", top:"50%", transform:"translateY(-50%)" },
    left:{ right:"calc(100% + 7px)", top:"50%", transform:"translateY(-50%)" },
  }[side];
  return (
    <span style={{ position:"relative", display:"inline-flex" }}
          onMouseEnter={()=>setShow(true)} onMouseLeave={()=>setShow(false)}>
      {children}
      {show && label && (
        <span style={{
          position:"absolute", ...pos, zIndex:200, pointerEvents:"none",
          background:"var(--bg-4)", color:"var(--text)", border:"1px solid var(--line-2)",
          padding:"4px 8px", borderRadius:"var(--r-sm)", fontSize:11, fontWeight:500,
          whiteSpace:"nowrap", boxShadow:"var(--shadow)", display:"flex", gap:6, alignItems:"center",
          animation:"appfade .1s var(--ease) both", letterSpacing:".01em",
        }}>
          {label}
          {kbd && <kbd style={{ fontFamily:"var(--mono)", fontSize:9.5, color:"var(--text-2)",
            border:"1px solid var(--line-2)", borderRadius:3, padding:"0 4px", lineHeight:"15px" }}>{kbd}</kbd>}
        </span>
      )}
    </span>
  );
}

/* ---- Button ---- */
function Btn({ kind="ghost", size="md", icon:Ic, iconR:IcR, children, active, full, style, className="", ...rest }){
  const sizes = {
    sm:{ h:26, px:8, fs:11.5, gap:5, isz:13 },
    md:{ h:30, px:11, fs:12.5, gap:6, isz:15 },
    lg:{ h:36, px:15, fs:13.5, gap:7, isz:16 },
    icon:{ h:30, w:30, px:0, fs:12.5, gap:0, isz:16 },
    iconSm:{ h:26, w:26, px:0, fs:12, gap:0, isz:15 },
  };
  const s = sizes[size] || sizes.md;
  const base = {
    display:"inline-flex", alignItems:"center", justifyContent:"center", gap:s.gap,
    height:s.h, width:s.w||(full?"100%":undefined), padding:`0 ${s.px}px`,
    borderRadius:"var(--r-md)", fontSize:s.fs, fontWeight:550, letterSpacing:".005em",
    cursor:"pointer", userSelect:"none", border:"1px solid transparent", whiteSpace:"nowrap",
    fontFamily:"var(--font)", lineHeight:1,
  };
  const kinds = {
    primary:{ background:"var(--accent)", color:"var(--accent-ink)", boxShadow:"0 1px 2px rgba(0,0,0,.18), 0 0 0 .5px var(--accent) inset" },
    solid:{ background:"var(--bg-4)", color:"var(--text)", borderColor:"var(--line-2)" },
    ghost:{ background: active?"var(--active)":"transparent", color: active?"var(--text)":"var(--text-1)", borderColor: active?"var(--line)":"transparent" },
    outline:{ background:"transparent", color:"var(--text)", borderColor:"var(--line-2)" },
    danger:{ background:"transparent", color:"#f87171", borderColor:"transparent" },
  };
  const [hov, setHov] = useState(false);
  const hovStyle = hov ? (
    kind==="primary" ? { filter:"brightness(1.08)" } :
    kind==="danger" ? { background:"rgba(248,113,113,.12)" } :
    { background:"var(--hover)", color:"var(--text)" }
  ) : null;
  return (
    <button {...rest} className={"tx ring "+className} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{ ...base, ...kinds[kind], ...hovStyle, ...style }}>
      {Ic && <Ic size={s.isz} />}
      {children}
      {IcR && <IcR size={s.isz} />}
    </button>
  );
}

/* ---- Segmented control ---- */
function Seg({ options, value, onChange, size="md" }){
  const h = size==="sm"?26:30;
  return (
    <div style={{ display:"inline-flex", padding:2, gap:2, background:"var(--bg-3)",
      border:"1px solid var(--line)", borderRadius:"var(--r-md)", height:h }}>
      {options.map(o=>{
        const val = o.value ?? o;
        const lab = o.label ?? o;
        const on = val===value;
        return (
          <button key={val} className="tx ring" onClick={()=>onChange(val)}
            style={{ display:"inline-flex", alignItems:"center", gap:5, padding:"0 10px",
              borderRadius:"var(--r-sm)", border:"none", cursor:"pointer", fontFamily:"var(--font)",
              fontSize:size==="sm"?11.5:12.5, fontWeight:550,
              background: on?"var(--bg-1)":"transparent",
              color: on?"var(--text)":"var(--text-2)",
              boxShadow: on?"0 1px 2px rgba(0,0,0,.15), 0 0 0 1px var(--line) ":"none" }}>
            {o.icon && <o.icon size={14} />}{lab}
          </button>
        );
      })}
    </div>
  );
}

/* ---- Toggle ---- */
function Toggle({ value, onChange, size=18 }){
  const w = size*1.75;
  return (
    <button className="tx ring" onClick={()=>onChange(!value)} role="switch" aria-checked={!!value}
      style={{ width:w, height:size, borderRadius:99, border:"1px solid",
        borderColor: value?"transparent":"var(--line-2)",
        background: value?"var(--accent)":"var(--bg-4)", padding:0, cursor:"pointer", position:"relative" }}>
      <span className="tx" style={{ position:"absolute", top:"50%", left: value?`calc(100% - ${size-3}px)`:"2px",
        transform:"translateY(-50%)", width:size-5, height:size-5, borderRadius:99,
        background: value?"var(--accent-ink)":"var(--text-2)", boxShadow:"0 1px 2px rgba(0,0,0,.3)" }} />
    </button>
  );
}

/* ---- Slider ---- */
function Slider({ value, min=0, max=100, step=1, onChange, format, width, accent=true, marks }){
  const ref = useRef(null);
  const pct = ((value-min)/(max-min))*100;
  const dragging = useRef(false);
  const setFromEvent = useCallback((e)=>{
    const r = ref.current.getBoundingClientRect();
    const x = (e.touches?e.touches[0].clientX:e.clientX) - r.left;
    let p = Math.max(0, Math.min(1, x/r.width));
    let v = min + p*(max-min);
    v = Math.round(v/step)*step;
    v = Math.max(min, Math.min(max, v));
    onChange(+v.toFixed(4));
  },[min,max,step,onChange]);
  useEffect(()=>{
    const move = e=>{ if(dragging.current){ e.preventDefault(); setFromEvent(e); } };
    const up = ()=>{ dragging.current=false; };
    window.addEventListener("mousemove",move); window.addEventListener("mouseup",up);
    return ()=>{ window.removeEventListener("mousemove",move); window.removeEventListener("mouseup",up); };
  },[setFromEvent]);
  return (
    <div style={{ width: width||"100%" }}>
      <div ref={ref} className="ring" tabIndex={0}
        onMouseDown={e=>{ dragging.current=true; setFromEvent(e); }}
        style={{ position:"relative", height:18, display:"flex", alignItems:"center", cursor:"pointer" }}>
        <div style={{ position:"absolute", left:0, right:0, height:4, borderRadius:99, background:"var(--bg-4)", border:"1px solid var(--line)" }} />
        <div style={{ position:"absolute", left:0, width:`${pct}%`, height:4, borderRadius:99,
          background: accent?"var(--accent)":"var(--text-2)" }} />
        {marks && marks.map(m=>(
          <div key={m} style={{ position:"absolute", left:`${((m-min)/(max-min))*100}%`, width:1.5, height:8,
            background:"var(--line-strong)", transform:"translateX(-50%)" }} />
        ))}
        <div className="tx" style={{ position:"absolute", left:`${pct}%`, transform:"translateX(-50%)",
          width:13, height:13, borderRadius:99, background:"var(--bg-1)",
          border:"1px solid var(--line-strong)", boxShadow:"0 1px 3px rgba(0,0,0,.3)" }} />
      </div>
      {format && <div className="mono" style={{ marginTop:3, fontSize:10.5, color:"var(--text-2)", textAlign:"right" }}>{format(value)}</div>}
    </div>
  );
}

/* ---- Avatar ---- */
function Avatar({ id, size=24, ring }){
  const sp = RC.SPEAKERS[id] || { initials:"?", hue:"var(--text-2)" };
  return (
    <span style={{ width:size, height:size, borderRadius:size>30?9:7, flexShrink:0,
      display:"inline-flex", alignItems:"center", justifyContent:"center",
      fontSize:size*0.38, fontWeight:700, letterSpacing:".02em",
      color:"#fff", background:`linear-gradient(150deg, ${sp.hue}, color-mix(in oklab, ${sp.hue} 70%, #000))`,
      boxShadow: ring?`0 0 0 2px var(--bg-1), 0 0 0 3.5px ${sp.hue}`:"inset 0 1px 0 rgba(255,255,255,.18)" }}>
      {sp.initials}
    </span>
  );
}

/* ---- Source chip ---- */
function SrcChip({ id, mini }){
  const sp = RC.SPEAKERS[id];
  if(!sp) return null;
  return (
    <span style={{ display:"inline-flex", alignItems:"center", gap:5, fontSize:mini?10.5:11.5,
      fontWeight:600, color:"var(--text-1)" }}>
      <span style={{ width:6, height:6, borderRadius:99, background:sp.hue, boxShadow:`0 0 6px ${sp.hue}` }} />
      {sp.name}
    </span>
  );
}

/* ---- Waveform ---- */
function Waveform({ seed, bars, height=28, color="var(--wave)", progress=null, gap=1.5, barW=2, rounded=true, style, mute }){
  const data = bars || RC.waveBars(seed||"x", 64);
  return (
    <div style={{ display:"flex", alignItems:"center", gap, height, width:"100%", opacity:mute?0.4:1, ...style }}>
      {data.map((v,i)=>{
        const played = progress!=null && (i/data.length) <= progress;
        return <div key={i} style={{ flex:1, minWidth:barW, height:`${Math.max(6,v*100)}%`,
          background: played?"var(--accent)":color, borderRadius: rounded?99:1,
          transition:"background .08s linear" }} />;
      })}
    </div>
  );
}

/* ---- Field / Select ---- */
function Select({ value, onChange, options, full, size="md" }){
  const h = size==="sm"?28:32;
  return (
    <div style={{ position:"relative", width: full?"100%":undefined }}>
      <select value={value} onChange={e=>onChange(e.target.value)} className="tx ring"
        style={{ appearance:"none", width:"100%", height:h, padding:"0 30px 0 10px",
          background:"var(--bg-3)", color:"var(--text)", border:"1px solid var(--line-2)",
          borderRadius:"var(--r-md)", fontSize:12.5, fontFamily:"var(--font)", fontWeight:500, cursor:"pointer" }}>
        {options.map(o=>{
          const val = o.value ?? o.code ?? o;
          const lab = o.label ?? o;
          return <option key={val} value={val}>{lab}</option>;
        })}
      </select>
      <span style={{ position:"absolute", right:9, top:"50%", transform:"translateY(-50%)", pointerEvents:"none", color:"var(--text-2)" }}>
        <I.chevD size={14} />
      </span>
    </div>
  );
}

/* ---- Section label ---- */
function SectionLabel({ children, right }){
  return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between",
      padding:"0 2px", marginBottom:9 }}>
      <span style={{ fontSize:10.5, fontWeight:700, letterSpacing:".09em", textTransform:"uppercase", color:"var(--text-2)" }}>{children}</span>
      {right}
    </div>
  );
}

/* ---- Stat / value row ---- */
function Row({ label, children, hint }){
  return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:12, minHeight:30 }}>
      <span style={{ fontSize:12, color:"var(--text-1)", fontWeight:500, flexShrink:0 }}>{label}
        {hint && <span style={{ color:"var(--text-3)", marginLeft:5, fontWeight:400 }}>{hint}</span>}
      </span>
      <div style={{ display:"flex", alignItems:"center", gap:8 }}>{children}</div>
    </div>
  );
}

/* ---- Badge ---- */
function Badge({ children, tone="default", style }){
  const tones = {
    default:{ bg:"var(--bg-3)", c:"var(--text-1)", b:"var(--line)" },
    accent:{ bg:"var(--accent-soft)", c:"var(--accent-text)", b:"var(--accent-line)" },
    mono:{ bg:"var(--bg-3)", c:"var(--text-2)", b:"var(--line)" },
  };
  const t = tones[tone]||tones.default;
  return <span className={tone==="mono"?"mono":""} style={{ display:"inline-flex", alignItems:"center", gap:4,
    height:18, padding:"0 6px", borderRadius:5, fontSize:10.5, fontWeight:600, letterSpacing:".02em",
    background:t.bg, color:t.c, border:`1px solid ${t.b}`, ...style }}>{children}</span>;
}

Object.assign(window, { Tooltip, Btn, Seg, Toggle, Slider, Avatar, SrcChip, Waveform, Select, SectionLabel, Row, Badge });
