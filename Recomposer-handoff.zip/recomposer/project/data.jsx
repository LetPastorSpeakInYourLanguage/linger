/* ============ Fake but realistic data for the Studio prototype ============ */

/* Deterministic pseudo-waveform bars from a seed. */
function waveBars(seed, n=64, lo=0.12){
  let h = 2166136261;
  for (let i=0;i<seed.length;i++){ h ^= seed.charCodeAt(i); h = Math.imul(h, 16777619); }
  const out = [];
  for (let i=0;i<n;i++){
    h ^= h << 13; h ^= h >>> 17; h ^= h << 5; h >>>= 0;
    let v = (h % 1000)/1000;
    // shape: gentle envelope so it reads like speech
    const env = 0.55 + 0.45*Math.sin((i/n)*Math.PI*(1.5 + (seed.charCodeAt(0)%4)));
    v = lo + Math.pow(v, 1.4) * env * (1-lo);
    out.push(Math.max(lo, Math.min(1, v)));
  }
  return out;
}

const SOURCES = {
  a: { id:"a", label:"Founder Interview — Maya Okonkwo", short:"INT_Maya_A", hue:"var(--src-a)", kind:"video", dur:1284 },
  b: { id:"b", label:"Field VO — Daniel Reyes",          short:"VO_Daniel",   hue:"var(--src-b)", kind:"audio", dur:622 },
  c: { id:"c", label:"Customer — Priya Anand",           short:"INT_Priya_C", hue:"var(--src-c)", kind:"video", dur:948 },
};

const SPEAKERS = {
  maya:   { id:"maya",   name:"Maya Okonkwo", role:"Founder & CEO", src:"a", initials:"MO", hue:"var(--src-a)" },
  daniel: { id:"daniel", name:"Daniel Reyes", role:"Narration",     src:"b", initials:"DR", hue:"var(--src-b)" },
  priya:  { id:"priya",  name:"Priya Anand",  role:"Customer",      src:"c", initials:"PA", hue:"var(--src-c)" },
};

/* The recomposition: an ordered list of cuts. transitionToNext describes the join. */
const CUTS = [
  { id:"c1", spk:"maya", srcIn:142.4, dur:9.2, gain:0,   fadeIn:0,   fadeOut:0,
    text:"People kept telling us the category was finished. That nobody wanted another one of these. We heard \u201ctoo late\u201d so many times it started to sound like advice.",
    trans:{ type:"cut", dur:0 } },
  { id:"c2", spk:"daniel", srcIn:18.0, dur:4.6, gain:-1.5, fadeIn:0.2, fadeOut:0,
    text:"So they did the one thing the incumbents had stopped doing. They listened.",
    trans:{ type:"crossfade", dur:0.35 } },
  { id:"c3", spk:"priya", srcIn:301.7, dur:7.8, gain:0.5, fadeIn:0, fadeOut:0,
    text:"I\u2019d basically given up on finding something that fit how I actually work. And then a friend just sent me a link, no pitch, nothing.",
    trans:{ type:"cut", dur:0 } },
  { id:"c4", spk:"maya", srcIn:486.1, dur:6.4, gain:0, fadeIn:0, fadeOut:0,
    text:"We didn\u2019t want louder. We wanted closer \u2014 closer to the work, and closer to the people actually doing it.",
    trans:{ type:"crossfade", dur:0.4 } },
  { id:"c5", spk:"priya", srcIn:512.9, dur:8.1, gain:0, fadeIn:0, fadeOut:0,
    text:"The first week it saved me maybe twenty minutes a day. By the end of the month I genuinely couldn\u2019t tell you how I worked before it.",
    trans:{ type:"cut", dur:0 } },
  { id:"c6", spk:"daniel", srcIn:204.5, dur:5.5, gain:-1.5, fadeIn:0, fadeOut:0,
    text:"Two years on, the category they were told was finished has a new center of gravity.",
    trans:{ type:"crossfade", dur:0.5 } },
  { id:"c7", spk:"maya", srcIn:902.0, dur:5.0, gain:0, fadeIn:0, fadeOut:0.8,
    text:"We\u2019re not done. Honestly, it feels like we just found the starting line.",
    trans:{ type:"end", dur:0 } },
];

/* Secondary tracks. */
const BEDS = [
  { id:"bed1", kind:"music", name:"Ascendant — Underscore", meta:"Licensed · 124 BPM", gain:-19, duck:true, start:0, dur:9999, hue:"var(--src-bed)" },
];
const OVERLAYS = [
  { id:"ov1", kind:"fx", name:"Riser → Impact", meta:"Transition SFX", gain:-8, start:13.6, dur:1.4, hue:"var(--src-fx)" },
  { id:"ov2", kind:"fx", name:"Soft swell",     meta:"Transition SFX", gain:-12, start:35.2, dur:1.8, hue:"var(--src-fx)" },
];

/* available clips in the left source panel (not yet in the comp) */
const SOURCE_CLIPS = [
  { id:"s1", spk:"maya",   dur:6.1, text:"The hardest part was believing the boring answer was the right one." },
  { id:"s2", spk:"maya",   dur:4.4, text:"Every shortcut we tried, the work got worse." },
  { id:"s3", spk:"priya",  dur:5.9, text:"It feels like it was built by someone who has my job." },
  { id:"s4", spk:"priya",  dur:3.7, text:"I stopped dreading the part I used to dread." },
  { id:"s5", spk:"daniel", dur:4.0, text:"The numbers were quiet at first. Then they weren\u2019t." },
  { id:"s6", spk:"daniel", dur:6.8, text:"What started as a side project became the standard." },
  { id:"s7", spk:"maya",   dur:5.2, text:"We measured the wrong thing for almost a year." },
  { id:"s8", spk:"priya",  dur:4.6, text:"My team noticed before I said a word." },
];

const LANGS = [
  { code:"none", label:"None (original)" },
  { code:"es", label:"Spanish" },
  { code:"fr", label:"French" },
  { code:"de", label:"German" },
  { code:"pt", label:"Portuguese (BR)" },
  { code:"ja", label:"Japanese" },
  { code:"hi", label:"Hindi" },
];

/* derived helpers */
function compTimeline(cuts){
  let t = 0; const items = [];
  cuts.forEach((c, i) => {
    const start = t;
    items.push({ ...c, start, end: start + c.dur, idx:i });
    const overlap = (c.trans && c.trans.type==="crossfade") ? c.trans.dur : 0;
    t = start + c.dur - overlap;
  });
  return { items, total: t };
}

function fmt(t){
  if (t==null || isNaN(t)) t = 0;
  const m = Math.floor(t/60);
  const s = Math.floor(t%60);
  const cs = Math.floor((t%1)*100);
  return `${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}.${String(cs).padStart(2,"0")}`;
}
function fmtShort(t){
  const m = Math.floor(t/60), s = Math.floor(t%60);
  return `${m}:${String(s).padStart(2,"0")}`;
}

window.RC = { SOURCES, SPEAKERS, CUTS, BEDS, OVERLAYS, SOURCE_CLIPS, LANGS, waveBars, compTimeline, fmt, fmtShort };
