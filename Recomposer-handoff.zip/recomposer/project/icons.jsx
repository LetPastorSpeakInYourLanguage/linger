/* Clean 1.5px stroke icon set. Each is a React component taking {size, strokeWidth, ...props}. */
const _svg = (size, sw, children, extra={}) =>
  React.createElement("svg", {
    width: size, height: size, viewBox: "0 0 24 24", fill: "none",
    stroke: "currentColor", strokeWidth: sw, strokeLinecap: "round", strokeLinejoin: "round",
    ...extra,
  }, children);

const _p = (d, k) => React.createElement("path", { d, key: k });
const _l = (x1,y1,x2,y2,k) => React.createElement("line", { x1,y1,x2,y2, key:k });
const _c = (cx,cy,r,k) => React.createElement("circle", { cx,cy,r, key:k });
const _r = (x,y,w,h,rx,k) => React.createElement("rect", { x,y,width:w,height:h,rx, key:k });

function makeIcon(render){
  return function Icon({ size=16, strokeWidth=1.6, ...rest }){
    return _svg(size, strokeWidth, render(), rest);
  };
}

const I = {
  play:      makeIcon(()=>[React.createElement("path",{key:0,d:"M6 4.5l13 7.5-13 7.5z",fill:"currentColor",stroke:"none"})]),
  pause:     makeIcon(()=>[_r(6,4.5,3.5,15,1,0),_r(14.5,4.5,3.5,15,1,1)].map((e,i)=>React.cloneElement(e,{fill:"currentColor",stroke:"none",key:i}))),
  skipBack:  makeIcon(()=>[_p("M11 6L5 12l6 6",0),_p("M19 6l-6 6 6 6",1)]),
  skipFwd:   makeIcon(()=>[_p("M13 6l6 6-6 6",0),_p("M5 6l6 6-6 6",1)]),
  toStart:   makeIcon(()=>[_l(6,5,6,19,0),_p("M19 6l-9 6 9 6z",1)]),
  toEnd:     makeIcon(()=>[_l(18,5,18,19,0),_p("M5 6l9 6-9 6z",1)]),
  library:   makeIcon(()=>[_r(3,4,7,16,1.5,0),_r(13,4,7,7,1.5,1),_r(13,14,7,6,1.5,2)]),
  film:      makeIcon(()=>[_r(3,4,18,16,2,0),_l(3,9,21,9,1),_l(3,15,21,15,2),_l(8,4,8,20,3),_l(16,4,16,20,4)]),
  scissors:  makeIcon(()=>[_c(6,6,2.4,0),_c(6,18,2.4,1),_p("M8 7.5L20 17",2),_p("M8 16.5L20 7",3)]),
  layers:    makeIcon(()=>[_p("M12 3l9 5-9 5-9-5z",0),_p("M3 13l9 5 9-5",1)]),
  studio:    makeIcon(()=>[_r(3,5,4,14,1,0),_r(10,5,4,14,1,1),_r(17,5,4,14,1,2),_l(5,9,5,9.01,3),_l(12,13,12,13.01,4)]),
  sliders:   makeIcon(()=>[_l(4,6,20,6,0),_l(4,12,20,12,1),_l(4,18,20,18,2),_c(9,6,2.2,3),_c(15,12,2.2,4),_c(7,18,2.2,5)]),
  settings:  makeIcon(()=>[_c(12,12,3,0),_p("M19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-2.9 1.2V23a2 2 0 11-4 0v-.1A1.7 1.7 0 005 21.2l-.1.1a2 2 0 11-2.8-2.8l.1-.1A1.7 1.7 0 002 15.6 1.7 1.7 0 00.8 14H.7a2 2 0 110-4h.1A1.7 1.7 0 002.6 8 1.7 1.7 0 002.3 6L2.2 6a2 2 0 112.8-2.8l.1.1A1.7 1.7 0 008 3.6V3.5a2 2 0 114 0v.1A1.7 1.7 0 0019 5l.1-.1A2 2 0 1121.9 7.7l-.1.1a1.7 1.7 0 00.4 2.8h.1a2 2 0 110 4h-.1a1.7 1.7 0 00-1.2 1z",1)]),
  sun:       makeIcon(()=>[_c(12,12,4,0),_l(12,2,12,4,1),_l(12,20,12,22,2),_l(4.2,4.2,5.6,5.6,3),_l(18.4,18.4,19.8,19.8,4),_l(2,12,4,12,5),_l(20,12,22,12,6),_l(4.2,19.8,5.6,18.4,7),_l(18.4,5.6,19.8,4.2,8)]),
  moon:      makeIcon(()=>[_p("M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z",0)]),
  search:    makeIcon(()=>[_c(11,11,7,0),_l(21,21,16.5,16.5,1)]),
  plus:      makeIcon(()=>[_l(12,5,12,19,0),_l(5,12,19,12,1)]),
  grip:      makeIcon(()=>[_c(9,6,1,0),_c(9,12,1,1),_c(9,18,1,2),_c(15,6,1,3),_c(15,12,1,4),_c(15,18,1,5)].map((e,i)=>React.cloneElement(e,{fill:"currentColor",stroke:"none",r:1.1,key:i}))),
  volume:    makeIcon(()=>[_p("M11 5L6 9H3v6h3l5 4z",0),_p("M15.5 8.5a5 5 0 010 7",1),_p("M18.5 6a8 8 0 010 12",2)]),
  mute:      makeIcon(()=>[_p("M11 5L6 9H3v6h3l5 4z",0),_l(22,9,16,15,1),_l(16,9,22,15,2)]),
  mic:       makeIcon(()=>[_r(9,3,6,11,3,0),_p("M5 11a7 7 0 0014 0",1),_l(12,18,12,21,2),_l(8.5,21,15.5,21,3)]),
  download:  makeIcon(()=>[_p("M12 3v12",0),_p("M7 11l5 4 5-4",1),_p("M4 19h16",2)]),
  share:     makeIcon(()=>[_c(18,6,2.6,0),_c(6,12,2.6,1),_c(18,18,2.6,2),_l(8.3,10.7,15.7,7.3,3),_l(8.3,13.3,15.7,16.7,4)]),
  undo:      makeIcon(()=>[_p("M9 7L4 12l5 5",0),_p("M4 12h11a5 5 0 010 10h-1",1)]),
  redo:      makeIcon(()=>[_p("M15 7l5 5-5 5",0),_p("M20 12H9a5 5 0 000 10h1",1)]),
  chevL:     makeIcon(()=>[_p("M15 6l-6 6 6 6",0)]),
  chevR:     makeIcon(()=>[_p("M9 6l6 6-6 6",0)]),
  chevD:     makeIcon(()=>[_p("M6 9l6 6 6-6",0)]),
  chevU:     makeIcon(()=>[_p("M6 15l6-6 6 6",0)]),
  x:         makeIcon(()=>[_l(6,6,18,18,0),_l(18,6,6,18,1)]),
  check:     makeIcon(()=>[_p("M5 12.5l4.5 4.5L19 6.5",0)]),
  fadeIn:    makeIcon(()=>[_p("M4 19L20 5",0),_l(4,19,20,19,1),_l(4,19,4,12,2)]),
  fadeOut:   makeIcon(()=>[_p("M4 5L20 19",0),_l(4,19,20,19,1),_l(20,19,20,12,2)]),
  split:     makeIcon(()=>[_l(12,3,12,21,0),_p("M7 8l-3 4 3 4",1),_p("M17 8l3 4-3 4",2)]),
  trash:     makeIcon(()=>[_p("M4 7h16",0),_p("M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2",1),_p("M6 7l1 13a1 1 0 001 1h8a1 1 0 001-1l1-13",2),_l(10,11,10,17,3),_l(14,11,14,17,4)]),
  wave:      makeIcon(()=>[_l(4,12,4,12.01,0),_l(8,8,8,16,1),_l(12,5,12,19,2),_l(16,9,16,15,3),_l(20,11,20,13,4)]),
  music:     makeIcon(()=>[_p("M9 18V5l11-2v13",0),_c(6,18,3,1),_c(17,16,3,2)]),
  globe:     makeIcon(()=>[_c(12,12,9,0),_l(3,12,21,12,1),_p("M12 3a14 14 0 010 18 14 14 0 010-18z",2)]),
  sparkle:   makeIcon(()=>[_p("M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z",0),_p("M19 15l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z",1)]),
  zoomIn:    makeIcon(()=>[_c(11,11,7,0),_l(21,21,16.5,16.5,1),_l(11,8,11,14,2),_l(8,11,14,11,3)]),
  zoomOut:   makeIcon(()=>[_c(11,11,7,0),_l(21,21,16.5,16.5,1),_l(8,11,14,11,2)]),
  lock:      makeIcon(()=>[_r(5,11,14,9,2,0),_p("M8 11V8a4 4 0 018 0v3",1)]),
  eye:       makeIcon(()=>[_p("M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z",0),_c(12,12,3,1)]),
  gauge:     makeIcon(()=>[_p("M12 13l4-4",0),_p("M3.5 16a9 9 0 1117 0",1),_c(12,13,1,2)]),
  dot:       makeIcon(()=>[React.createElement("circle",{key:0,cx:12,cy:12,r:4,fill:"currentColor",stroke:"none"})]),
  link:      makeIcon(()=>[_p("M10 14a4 4 0 005.7 0l3-3a4 4 0 10-5.7-5.7l-1.5 1.5",0),_p("M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 105.7 5.7l1.5-1.5",1)]),
  clock:     makeIcon(()=>[_c(12,12,9,0),_p("M12 7v5l3 2",1)]),
  more:      makeIcon(()=>[_c(5,12,1,0),_c(12,12,1,1),_c(19,12,1,2)].map((e,i)=>React.cloneElement(e,{fill:"currentColor",stroke:"none",r:1.4,key:i}))),
  drag:      makeIcon(()=>[_l(8,7,16,7,0),_l(8,12,16,12,1),_l(8,17,16,17,2)]),
  flag:      makeIcon(()=>[_p("M5 21V4h11l-1.5 3.5L16 11H5",0)]),
  loud:      makeIcon(()=>[_l(4,14,4,18,0),_l(8,10,8,18,1),_l(12,6,12,18,2),_l(16,11,16,18,3),_l(20,8,20,18,4)]),
};

window.I = I;
