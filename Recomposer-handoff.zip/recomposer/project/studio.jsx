/* ===================== Studio: Player · Script · Timeline · Export ===================== */
const { useState:uS, useRef:uR, useEffect:uE, useMemo:uM, useCallback:uC, useLayoutEffect:uL } = React;

/* overview waveform bars across the whole comp */
function overviewBars(items, total, n=240){
  const out = [];
  for(let i=0;i<n;i++){
    const t = (i/n)*total;
    const cut = items.find(c=> t>=c.start && t<c.end) || items[items.length-1];
    const local = cut ? (t-cut.start)/Math.max(0.01,cut.dur) : 0;
    const bars = RC.waveBars(cut?cut.id:"x", 48);
    const v = bars[Math.floor(local*48)%48];
    out.push(v);
  }
  return out;
}

/* ===================== PLAYER ===================== */
function Player({ t, total, playing, onPlay, onSeek, items, activeCut, speed, onSpeed, vol, onVol, loop, onLoop }){
  const prog = total? t/total : 0;
  const sp = activeCut ? RC.SPEAKERS[activeCut.spk] : null;
  const ov = uM(()=>overviewBars(items, total), [items, total]);
  const barRef = uR(null);
  const seek = (e)=>{
    const r = barRef.current.getBoundingClientRect();
    const p = Math.max(0, Math.min(1, (e.clientX-r.left)/r.width));
    onSeek(p*total);
  };
  const dragging = uR(false);
  uE(()=>{
    const mv = e=>{ if(dragging.current) seek(e); };
    const up = ()=>dragging.current=false;
    window.addEventListener("mousemove",mv); window.addEventListener("mouseup",up);
    return ()=>{ window.removeEventListener("mousemove",mv); window.removeEventListener("mouseup",up); };
  },[total]);

  return (
    <div style={{ display:"flex", gap:16, padding:"15px 18px", borderBottom:"1px solid var(--line)", background:"var(--bg-1)", flexShrink:0 }}>
      {/* preview */}
      <div style={{ width:300, aspectRatio:"16/9", borderRadius:"var(--r-lg)", overflow:"hidden", position:"relative",
        flexShrink:0, border:"1px solid var(--line-2)", background:"#08080a",
        boxShadow:"var(--shadow)" }}>
        <div style={{ position:"absolute", inset:0, background: sp
          ? `radial-gradient(120% 90% at 30% 25%, color-mix(in oklab, ${sp.hue} 32%, #0a0a0c), #08080a 70%)`
          : "#0a0a0c", transition:"background .4s var(--ease)" }} />
        {/* grain */}
        <div style={{ position:"absolute", inset:0, opacity:.5, mixBlendMode:"overlay",
          backgroundImage:"url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.5'/%3E%3C/svg%3E\")" }} />
        {sp && <>
          <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center" }}>
            <div style={{ transform: playing?"scale(1.02)":"scale(1)", transition:"transform 2s var(--ease)" }}><Avatar id={sp.id} size={66} /></div>
          </div>
          {/* lower third */}
          <div style={{ position:"absolute", left:14, bottom:13, right:14 }}>
            <div style={{ display:"inline-flex", flexDirection:"column", gap:2, padding:"7px 11px", borderRadius:8,
              background:"rgba(8,8,10,.55)", backdropFilter:"blur(8px)", borderLeft:`2.5px solid ${sp.hue}` }}>
              <span style={{ color:"#fff", fontSize:13, fontWeight:650, lineHeight:1.1 }}>{sp.name}</span>
              <span style={{ color:"rgba(255,255,255,.62)", fontSize:10.5 }}>{sp.role}</span>
            </div>
          </div>
        </>}
        <div className="mono" style={{ position:"absolute", top:10, right:11, fontSize:10, color:"rgba(255,255,255,.7)",
          background:"rgba(8,8,10,.5)", padding:"2px 6px", borderRadius:4 }}>{RC.fmt(t)}</div>
        <div style={{ position:"absolute", top:10, left:11, display:"flex", alignItems:"center", gap:5,
          fontSize:9.5, fontWeight:700, letterSpacing:".08em", color:"rgba(255,255,255,.78)" }}>
          <span style={{ width:6, height:6, borderRadius:99, background:"#f43f5e", boxShadow:"0 0 7px #f43f5e",
            animation: playing?"appfade 1s steps(2) infinite alternate":"none" }} />PREVIEW
        </div>
      </div>

      {/* transport + scrubber */}
      <div style={{ flex:1, minWidth:0, display:"flex", flexDirection:"column" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:4 }}>
          <div style={{ display:"flex", alignItems:"center", gap:9 }}>
            <span style={{ fontSize:13.5, fontWeight:650 }}>Q3 Brand Film</span>
            <Badge tone="accent">Director&rsquo;s cut</Badge>
            <span style={{ fontSize:11.5, color:"var(--text-2)" }}>{items.length} clips</span>
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:7 }}>
            <span style={{ fontSize:11, color:"var(--text-2)", display:"flex", alignItems:"center", gap:5 }}>
              <I.loud size={13} /> −14 LUFS</span>
          </div>
        </div>

        {/* master scrubber */}
        <div ref={barRef} onMouseDown={e=>{ dragging.current=true; seek(e); }}
          style={{ position:"relative", height:46, marginTop:6, marginBottom:8, cursor:"pointer", borderRadius:8,
            background:"var(--bg-3)", border:"1px solid var(--line)", padding:"0 2px", overflow:"hidden" }}>
          {/* cut region tints */}
          {items.map(c=>(
            <div key={c.id} style={{ position:"absolute", top:0, bottom:0, left:`${(c.start/total)*100}%`,
              width:`${(c.dur/total)*100}%`, background:`color-mix(in oklab, ${RC.SPEAKERS[c.spk].hue} 9%, transparent)`,
              borderLeft: c.idx>0?"1px solid var(--line)":"none" }} />
          ))}
          {/* overview waveform */}
          <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", gap:1, padding:"0 4px" }}>
            {ov.map((v,i)=>{
              const played = (i/ov.length)<=prog;
              return <div key={i} style={{ flex:1, height:`${20+v*52}%`, borderRadius:99,
                background: played?"var(--accent)":"var(--wave)", opacity: played?0.95:0.5 }} />;
            })}
          </div>
          {/* playhead */}
          <div style={{ position:"absolute", top:-1, bottom:-1, left:`${prog*100}%`, width:2, background:"var(--accent-2)",
            boxShadow:"0 0 8px var(--accent-glow)", transform:"translateX(-1px)" }}>
            <div style={{ position:"absolute", top:-1, left:"50%", transform:"translateX(-50%)", width:9, height:9,
              borderRadius:99, background:"var(--accent-2)", border:"1.5px solid var(--bg-1)" }} />
          </div>
        </div>

        {/* controls */}
        <div style={{ display:"flex", alignItems:"center", gap:14 }}>
          <div style={{ display:"flex", alignItems:"center", gap:2 }}>
            <Tooltip label="To start" kbd="Home"><Btn size="icon" kind="ghost" onClick={()=>onSeek(0)}><I.toStart size={16} /></Btn></Tooltip>
            <Tooltip label="Back 5s" kbd="J"><Btn size="icon" kind="ghost" onClick={()=>onSeek(Math.max(0,t-5))}><I.skipBack size={17} /></Btn></Tooltip>
            <Tooltip label={playing?"Pause":"Play"} kbd="Space">
              <button className="tx ring" onClick={onPlay} style={{ width:44, height:44, borderRadius:99, margin:"0 2px",
                border:"none", cursor:"pointer", background:"var(--accent)", color:"var(--accent-ink)",
                display:"flex", alignItems:"center", justifyContent:"center",
                boxShadow:"0 4px 14px -4px var(--accent-glow), 0 0 0 1px var(--accent) inset" }}>
                {playing? <I.pause size={20} /> : <I.play size={20} />}
              </button>
            </Tooltip>
            <Tooltip label="Forward 5s" kbd="L"><Btn size="icon" kind="ghost" onClick={()=>onSeek(Math.min(total,t+5))}><I.skipFwd size={17} /></Btn></Tooltip>
            <Tooltip label="To end" kbd="End"><Btn size="icon" kind="ghost" onClick={()=>onSeek(total)}><I.toEnd size={16} /></Btn></Tooltip>
          </div>

          <div className="mono" style={{ fontSize:13, fontWeight:500, letterSpacing:".01em" }}>
            <span style={{ color:"var(--text)" }}>{RC.fmt(t)}</span>
            <span style={{ color:"var(--text-3)", margin:"0 6px" }}>/</span>
            <span style={{ color:"var(--text-2)" }}>{RC.fmt(total)}</span>
          </div>

          <div style={{ flex:1 }} />

          <Tooltip label="Loop"><Btn size="icon" kind="ghost" active={loop} onClick={()=>onLoop(!loop)}><I.redo size={16} /></Btn></Tooltip>
          <div style={{ display:"flex", alignItems:"center", gap:6, width:120 }}>
            <I.volume size={15} style={{ color:"var(--text-2)", flexShrink:0 }} />
            <Slider value={vol} min={0} max={100} step={1} onChange={onVol} />
          </div>
          <Select value={speed} onChange={v=>onSpeed(+v)} size="sm"
            options={[{value:0.5,label:"0.5×"},{value:1,label:"1×"},{value:1.5,label:"1.5×"},{value:2,label:"2×"}]} />
        </div>
      </div>
    </div>
  );
}

/* ===================== SCRIPT (transcript-as-timeline) ===================== */
function TransitionDivider({ trans, onInsert }){
  const labelMap = { cut:"Hard cut", crossfade:`${trans.dur.toFixed(2)}s crossfade`, gap:`${trans.dur.toFixed(2)}s gap` };
  return (
    <div className="transdiv" style={{ display:"flex", alignItems:"center", gap:10, padding:"3px 0 3px 52px", position:"relative" }}
      onMouseEnter={e=>e.currentTarget.querySelector(".ins").style.opacity=1}
      onMouseLeave={e=>e.currentTarget.querySelector(".ins").style.opacity=0}>
      <div style={{ display:"flex", alignItems:"center", gap:6, color:"var(--text-2)" }}>
        {trans.type==="crossfade" ? <I.fadeIn size={12} /> : trans.type==="gap" ? <I.clock size={12} /> : <I.scissors size={12} />}
        <span style={{ fontSize:10.5, fontWeight:600, letterSpacing:".02em" }}>{labelMap[trans.type]}</span>
      </div>
      <div style={{ flex:1, height:1, background:"repeating-linear-gradient(90deg, var(--line) 0 5px, transparent 5px 10px)" }} />
      <button className="ins tx" onClick={onInsert} style={{ opacity:0, display:"inline-flex", alignItems:"center", gap:4,
        height:20, padding:"0 7px", borderRadius:99, cursor:"pointer", fontFamily:"var(--font)",
        fontSize:10.5, fontWeight:600, color:"var(--text-1)", border:"1px solid var(--line-2)", background:"var(--bg-2)" }}>
        <I.plus size={12} /> Insert
      </button>
    </div>
  );
}

function ScriptBlock({ cut, idx, selected, isActive, localProg, onSelect, onPlayFrom, onPatch, onRemove, dragHandlers, dragOver }){
  const sp = RC.SPEAKERS[cut.spk];
  const src = RC.SOURCES[sp.src];
  const words = uM(()=>cut.text.split(" "), [cut.text]);
  const activeWord = isActive ? Math.floor(localProg*words.length) : -1;
  const [hov, setHov] = uS(false);
  return (
    <div {...dragHandlers}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      onClick={()=>onSelect()}
      style={{ display:"flex", gap:12, padding:"11px 12px 12px 8px", borderRadius:"var(--r-lg)", cursor:"pointer", position:"relative",
        background: selected?"var(--accent-soft)":(hov?"var(--hover)":"transparent"),
        boxShadow: selected?"inset 0 0 0 1px var(--accent-line)":"inset 0 0 0 1px transparent",
        borderTop: dragOver?"2px solid var(--accent)":"2px solid transparent",
        transition:"background .12s var(--ease)" }}>
      {/* left selection bar when active playing */}
      {isActive && <div style={{ position:"absolute", left:0, top:8, bottom:8, width:3, borderRadius:99, background:"var(--accent)" }} />}
      {/* gutter */}
      <div style={{ width:34, flexShrink:0, display:"flex", flexDirection:"column", alignItems:"center", gap:6, paddingTop:2 }}>
        <span className="grip tx" {...(dragHandlers.handle||{})} style={{ cursor:"grab", color: hov?"var(--text-2)":"var(--text-3)", opacity: hov?1:0.5 }}><I.grip size={15} /></span>
        <span className="mono" style={{ fontSize:11, fontWeight:600, color: selected?"var(--accent-text)":"var(--text-2)" }}>{String(idx+1).padStart(2,"0")}</span>
        <Avatar id={cut.spk} size={26} />
      </div>
      {/* body */}
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:5 }}>
          <span style={{ fontSize:12.5, fontWeight:650 }}>{sp.name}</span>
          <span style={{ width:5, height:5, borderRadius:99, background:sp.hue }} />
          <span className="mono" style={{ fontSize:10.5, color:"var(--text-2)" }}>{src.short}</span>
          <span className="mono" style={{ fontSize:10.5, color:"var(--text-3)" }}>{RC.fmt(cut.srcIn)}\u2013{RC.fmt(cut.srcIn+cut.dur)}</span>
          {cut.gain!==0 && <Badge tone="mono">{cut.gain>0?"+":""}{cut.gain}dB</Badge>}
          <div style={{ flex:1 }} />
          {/* hover actions */}
          <div className="tx" style={{ display:"flex", gap:1, opacity: hov||selected?1:0, transition:"opacity .12s" }}>
            <Tooltip label="Play from here"><Btn size="iconSm" kind="ghost" onClick={e=>{e.stopPropagation(); onPlayFrom();}}><I.play size={13} /></Btn></Tooltip>
            <Tooltip label={cut.muted?"Unmute":"Mute"}><Btn size="iconSm" kind="ghost" onClick={e=>{e.stopPropagation(); onPatch({muted:!cut.muted});}}>{cut.muted?<I.mute size={14}/>:<I.volume size={14}/>}</Btn></Tooltip>
            <Tooltip label="Split"><Btn size="iconSm" kind="ghost" onClick={e=>e.stopPropagation()}><I.split size={14} /></Btn></Tooltip>
            <Tooltip label="Remove"><Btn size="iconSm" kind="ghost" onClick={e=>{e.stopPropagation(); onRemove();}}><I.trash size={14} /></Btn></Tooltip>
          </div>
          <span className="mono" style={{ fontSize:10.5, color:"var(--text-2)", width:42, textAlign:"right" }}>{cut.dur.toFixed(1)}s</span>
        </div>
        <div style={{ fontSize:"var(--script-fs, 15px)", lineHeight:1.62, color: cut.muted?"var(--text-3)":"var(--text)", letterSpacing:"-.003em",
          textDecoration: cut.muted?"line-through":"none", textDecorationColor:"var(--text-3)" }}>
          {words.map((w,i)=>{
            const isCur = i===activeWord;
            const isPast = isActive && i<activeWord;
            return <span key={i} style={{ background: isCur?"var(--accent-soft)":"transparent", borderRadius:3,
              padding: isCur?"1px 1px":"0", color: isCur?"var(--accent-text)": isPast?"var(--text)":(cut.muted?"var(--text-3)":"var(--text-1)"),
              transition:"color .1s, background .1s", fontWeight: isCur?600:400 }}>{w}{" "}</span>;
          })}
        </div>
        <div style={{ marginTop:9, opacity: cut.muted?0.4:0.9 }}>
          <Waveform seed={cut.id} height={20} barW={1.8} progress={isActive?localProg:null}
            color="color-mix(in oklab, var(--wave) 80%, transparent)" />
        </div>
      </div>
    </div>
  );
}

function Script({ items, total, t, selectedId, onSelect, onSeek, onPatch, onRemove, onReorder, onInsertAfter }){
  const [dragIdx, setDragIdx] = uS(null);
  const [overIdx, setOverIdx] = uS(null);
  const [find, setFind] = uS("");
  const [showFind, setShowFind] = uS(false);

  const dh = (i)=>({
    handle:{
      draggable:true,
      onDragStart:(e)=>{ setDragIdx(i); e.dataTransfer.effectAllowed="move"; },
      onDragEnd:()=>{ setDragIdx(null); setOverIdx(null); },
    },
    onDragOver:(e)=>{ if(dragIdx!=null){ e.preventDefault(); setOverIdx(i); } },
    onDrop:(e)=>{ e.preventDefault(); if(dragIdx!=null && dragIdx!==i){ onReorder(dragIdx,i); } setDragIdx(null); setOverIdx(null); },
  });

  return (
    <div style={{ flex:1, minHeight:0, display:"flex", flexDirection:"column", background:"var(--bg)" }}>
      {/* script toolbar */}
      <div style={{ display:"flex", alignItems:"center", gap:10, padding:"9px 16px", borderBottom:"1px solid var(--line)",
        flexShrink:0, background:"var(--bg-1)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:7 }}>
          <I.studio size={15} style={{ color:"var(--text-2)" }} />
          <span style={{ fontSize:12.5, fontWeight:650 }}>Script</span>
          <span style={{ fontSize:11.5, color:"var(--text-2)" }}>edit the film by editing the words</span>
        </div>
        <div style={{ flex:1 }} />
        {showFind && (
          <input autoFocus value={find} onChange={e=>setFind(e.target.value)} placeholder="Find in transcript\u2026"
            onBlur={()=>{ if(!find) setShowFind(false); }} className="tx ring"
            style={{ width:200, height:28, padding:"0 10px", background:"var(--bg-3)", color:"var(--text)",
              border:"1px solid var(--line-2)", borderRadius:"var(--r-md)", fontSize:12, fontFamily:"var(--font)", outline:"none" }} />
        )}
        <Tooltip label="Find" kbd="/"><Btn size="icon" kind="ghost" onClick={()=>setShowFind(s=>!s)}><I.search size={15} /></Btn></Tooltip>
        <div style={{ width:1, height:18, background:"var(--line)" }} />
        <Seg size="sm" value="script" onChange={()=>{}}
          options={[{value:"script",label:"Script",icon:I.studio},{value:"board",label:"Storyboard",icon:I.film}]} />
      </div>

      {/* blocks */}
      <div style={{ flex:1, overflowY:"auto", padding:"12px 16px 40px" }}>
        <div style={{ maxWidth:760, margin:"0 auto" }}>
          {items.map((c,i)=>{
            const isActive = t>=c.start && t<c.end;
            const localProg = isActive ? (t-c.start)/Math.max(0.01,c.dur) : 0;
            const dim = find && !c.text.toLowerCase().includes(find.toLowerCase());
            return (
              <div key={c.id} style={{ opacity: dim?0.32:1, transition:"opacity .15s" }}>
                <ScriptBlock cut={c} idx={i} selected={selectedId===c.id} isActive={isActive} localProg={localProg}
                  onSelect={()=>onSelect(c.id)} onPlayFrom={()=>onSeek(c.start)}
                  onPatch={p=>onPatch(c.id,p)} onRemove={()=>onRemove(c.id)}
                  dragHandlers={dh(i)} dragOver={overIdx===i && dragIdx!==i} />
                {c.trans.type!=="end" && <TransitionDivider trans={c.trans} onInsert={()=>onInsertAfter(i)} />}
              </div>
            );
          })}
          {/* end cap */}
          <div style={{ display:"flex", alignItems:"center", gap:10, padding:"14px 0 0 52px", color:"var(--text-3)" }}>
            <I.flag size={13} /><span style={{ fontSize:11, fontWeight:600, letterSpacing:".03em" }}>END OF RECOMPOSITION · {RC.fmt(total)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ===================== TIMELINE ===================== */
function Timeline({ items, total, t, selectedId, onSelect, onSeek, bed, overlays, collapsed, onCollapse }){
  const [zoom, setZoom] = uS(1);
  const railRef = uR(null);
  const pxPerSec = 13 * zoom;
  const width = Math.max(total*pxPerSec, 600);
  const seek = (e)=>{
    const r = railRef.current.getBoundingClientRect();
    const x = e.clientX - r.left + railRef.current.scrollLeft;
    onSeek(Math.max(0, Math.min(total, x/pxPerSec)));
  };
  const dragging = uR(false);
  uE(()=>{
    const mv=e=>{ if(dragging.current) seek(e); };
    const up=()=>dragging.current=false;
    window.addEventListener("mousemove",mv); window.addEventListener("mouseup",up);
    return ()=>{ window.removeEventListener("mousemove",mv); window.removeEventListener("mouseup",up); };
  },[total,zoom]);

  const ticks = [];
  for(let s=0;s<=Math.ceil(total);s+=5) ticks.push(s);
  const TRACK_H = 40, LABEL_W = 92;

  if(collapsed){
    return (
      <div style={{ flexShrink:0, height:34, borderTop:"1px solid var(--line)", background:"var(--bg-1)",
        display:"flex", alignItems:"center", padding:"0 14px", gap:10 }}>
        <Btn size="iconSm" kind="ghost" onClick={()=>onCollapse(false)}><I.chevU size={15} /></Btn>
        <span style={{ fontSize:11.5, fontWeight:600, color:"var(--text-1)" }}>Timeline</span>
        <span style={{ fontSize:11, color:"var(--text-2)" }}>{items.length} clips · 3 tracks · {RC.fmt(total)}</span>
      </div>
    );
  }

  const Track = ({ label, color, icon:Ic, children })=>(
    <div style={{ display:"flex", height:TRACK_H, borderBottom:"1px solid var(--line)" }}>
      <div style={{ width:LABEL_W, flexShrink:0, borderRight:"1px solid var(--line)", display:"flex", alignItems:"center",
        gap:6, padding:"0 10px", background:"var(--bg-1)", position:"sticky", left:0, zIndex:5 }}>
        <span style={{ width:7, height:7, borderRadius:2, background:color }} />
        <span style={{ fontSize:10.5, fontWeight:600, color:"var(--text-1)", whiteSpace:"nowrap" }}>{label}</span>
      </div>
      <div style={{ position:"relative", flex:1 }}>{children}</div>
    </div>
  );

  return (
    <div style={{ flexShrink:0, height:182, borderTop:"1px solid var(--line)", background:"var(--bg-1)",
      display:"flex", flexDirection:"column" }}>
      {/* header */}
      <div style={{ display:"flex", alignItems:"center", gap:10, padding:"7px 14px", borderBottom:"1px solid var(--line)" }}>
        <Btn size="iconSm" kind="ghost" onClick={()=>onCollapse(true)}><I.chevD size={15} /></Btn>
        <span style={{ fontSize:12, fontWeight:650 }}>Timeline</span>
        <Badge tone="mono">{RC.fmt(total)}</Badge>
        <div style={{ flex:1 }} />
        <span className="mono" style={{ fontSize:11, color:"var(--accent-text)" }}>{RC.fmt(t)}</span>
        <div style={{ width:1, height:16, background:"var(--line)" }} />
        <Tooltip label="Zoom out"><Btn size="iconSm" kind="ghost" onClick={()=>setZoom(z=>Math.max(0.5,z-0.5))}><I.zoomOut size={15} /></Btn></Tooltip>
        <span className="mono" style={{ fontSize:10.5, color:"var(--text-2)", width:30, textAlign:"center" }}>{Math.round(zoom*100)}%</span>
        <Tooltip label="Zoom in"><Btn size="iconSm" kind="ghost" onClick={()=>setZoom(z=>Math.min(4,z+0.5))}><I.zoomIn size={15} /></Btn></Tooltip>
      </div>

      {/* scroll area */}
      <div ref={railRef} style={{ flex:1, overflowX:"auto", overflowY:"hidden", position:"relative" }}>
        <div style={{ width: width+LABEL_W, position:"relative" }}>
          {/* ruler */}
          <div style={{ display:"flex", height:22, borderBottom:"1px solid var(--line)", position:"sticky", top:0, zIndex:4, background:"var(--bg-1)" }}
            onMouseDown={e=>{ dragging.current=true; seek(e); }}>
            <div style={{ width:LABEL_W, flexShrink:0, borderRight:"1px solid var(--line)", position:"sticky", left:0, background:"var(--bg-1)", zIndex:5,
              display:"flex", alignItems:"center", padding:"0 10px" }}>
              <span style={{ fontSize:9.5, fontWeight:700, letterSpacing:".07em", color:"var(--text-3)" }}>TRACKS</span>
            </div>
            <div style={{ position:"relative", flex:1, cursor:"pointer" }}>
              {ticks.map(s=>(
                <div key={s} style={{ position:"absolute", left:s*pxPerSec, top:0, bottom:0, borderLeft:"1px solid var(--line)" }}>
                  <span className="mono" style={{ position:"absolute", left:4, top:4, fontSize:9.5, color:"var(--text-3)" }}>{RC.fmtShort(s)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* dialogue track */}
          <Track label="Dialogue" color="var(--accent)" onMouseDown={e=>{dragging.current=true; seek(e);}}>
            <div style={{ position:"absolute", inset:0 }} onMouseDown={e=>{ dragging.current=true; seek(e); }} />
            {items.map(c=>{
              const sp = RC.SPEAKERS[c.spk];
              const on = selectedId===c.id;
              return (
                <div key={c.id} onClick={(e)=>{ e.stopPropagation(); onSelect(c.id); onSeek(c.start+0.01); }}
                  className="tx" title={sp.name}
                  style={{ position:"absolute", top:4, bottom:4, left:c.start*pxPerSec, width:Math.max(8,c.dur*pxPerSec-1.5),
                    borderRadius:5, cursor:"pointer", overflow:"hidden", zIndex:2,
                    background: `color-mix(in oklab, ${sp.hue} ${on?28:16}%, var(--bg-2))`,
                    border:`1px solid ${on?sp.hue:"color-mix(in oklab, "+sp.hue+" 35%, transparent)"}`,
                    boxShadow: on?`0 0 0 1px ${sp.hue}`:"none" }}>
                  <div style={{ display:"flex", alignItems:"center", gap:4, padding:"2px 5px 0" }}>
                    <span style={{ width:5, height:5, borderRadius:99, background:sp.hue, flexShrink:0 }} />
                    <span style={{ fontSize:9.5, fontWeight:650, color:"var(--text-1)", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{sp.name.split(" ")[0]}</span>
                  </div>
                  <div style={{ position:"absolute", left:5, right:4, bottom:3 }}>
                    <Waveform seed={c.id} height={12} barW={1.4} gap={1} rounded={false}
                      color={`color-mix(in oklab, ${sp.hue} 60%, transparent)`} />
                  </div>
                </div>
              );
            })}
          </Track>

          {/* music bed */}
          <Track label="Music bed" color="var(--src-bed)">
            <div style={{ position:"absolute", inset:0 }} onMouseDown={e=>{ dragging.current=true; seek(e); }} />
            <div style={{ position:"absolute", top:4, bottom:4, left:0, width:total*pxPerSec-1.5, borderRadius:5, overflow:"hidden",
              background:"color-mix(in oklab, var(--src-bed) 13%, var(--bg-2))",
              border:"1px solid color-mix(in oklab, var(--src-bed) 32%, transparent)", display:"flex", alignItems:"center", padding:"0 7px", gap:6, zIndex:2 }}>
              <I.music size={12} style={{ color:"var(--src-bed)", flexShrink:0 }} />
              <span style={{ fontSize:9.5, fontWeight:600, color:"var(--text-1)", whiteSpace:"nowrap" }}>{bed.name}</span>
              <span className="mono" style={{ fontSize:9, color:"var(--text-2)" }}>{bed.gain}dB{bed.duck?" · duck":""}</span>
              <div style={{ flex:1, opacity:.5 }}><Waveform seed="bedwave" height={12} barW={1.2} gap={1} rounded={false} color="color-mix(in oklab, var(--src-bed) 55%, transparent)" /></div>
            </div>
          </Track>

          {/* overlays */}
          <Track label="SFX / Overlay" color="var(--src-fx)">
            <div style={{ position:"absolute", inset:0 }} onMouseDown={e=>{ dragging.current=true; seek(e); }} />
            {overlays.map(o=>(
              <div key={o.id} style={{ position:"absolute", top:4, bottom:4, left:o.start*pxPerSec, width:Math.max(16,o.dur*pxPerSec),
                borderRadius:5, background:"color-mix(in oklab, var(--src-fx) 16%, var(--bg-2))",
                border:"1px solid color-mix(in oklab, var(--src-fx) 36%, transparent)", display:"flex", alignItems:"center",
                justifyContent:"center", gap:4, zIndex:2 }} title={o.name}>
                <I.wave size={11} style={{ color:"var(--src-fx)" }} />
              </div>
            ))}
          </Track>

          {/* playhead spanning tracks */}
          <div style={{ position:"absolute", top:0, bottom:0, left:LABEL_W + t*pxPerSec, width:1.5,
            background:"var(--accent-2)", zIndex:8, pointerEvents:"none", boxShadow:"0 0 8px var(--accent-glow)" }}>
            <div style={{ position:"absolute", top:0, left:"50%", transform:"translateX(-50%)", width:0, height:0,
              borderLeft:"5px solid transparent", borderRight:"5px solid transparent", borderTop:"6px solid var(--accent-2)" }} />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ===================== EXPORT PANEL ===================== */
function ExportPanel({ exportCfg, setExportCfg, total, items, render, onExport }){
  const cfg = exportCfg;
  const set = (p)=>setExportCfg({...cfg, ...p});
  const dub = cfg.lang!=="none" && cfg.dub;
  const langLabel = (RC.LANGS.find(l=>l.code===cfg.lang)||{}).label;

  if(render.state==="rendering" || render.state==="done"){
    return (
      <div style={{ padding:"18px 16px" }}>
        <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:16 }}>
          <Btn size="sm" kind="ghost" icon={I.chevL} onClick={()=>onExport("reset")}>Back</Btn>
        </div>
        {render.state==="rendering" ? (
          <div>
            <div style={{ width:54, height:54, borderRadius:14, margin:"6px auto 16px", background:"var(--accent-soft)",
              border:"1px solid var(--accent-line)", display:"flex", alignItems:"center", justifyContent:"center", color:"var(--accent-text)" }}>
              <div style={{ animation:"spin 1s linear infinite", display:"flex" }}><I.gauge size={24} /></div>
            </div>
            <div style={{ textAlign:"center", fontSize:14, fontWeight:650, marginBottom:3 }}>Rendering recomposition</div>
            <div style={{ textAlign:"center", fontSize:12, color:"var(--text-2)", marginBottom:20 }}>{render.stage}</div>
            <div style={{ height:7, borderRadius:99, background:"var(--bg-3)", overflow:"hidden", border:"1px solid var(--line)" }}>
              <div style={{ height:"100%", width:`${render.pct}%`, background:"linear-gradient(90deg, var(--accent), var(--accent-2))",
                borderRadius:99, transition:"width .3s var(--ease)" }} />
            </div>
            <div className="mono" style={{ textAlign:"center", fontSize:11, color:"var(--text-2)", marginTop:8 }}>{render.pct}%</div>
            <div style={{ marginTop:22, display:"flex", flexDirection:"column", gap:2 }}>
              {render.log.map((l,i)=>(
                <div key={i} className="mono" style={{ fontSize:10.5, color: i===render.log.length-1?"var(--text-1)":"var(--text-3)",
                  display:"flex", gap:7, alignItems:"center" }}>
                  <I.check size={12} style={{ color:"var(--src-fx)", flexShrink:0 }} />{l}</div>
              ))}
            </div>
          </div>
        ) : (
          <div>
            <div style={{ width:54, height:54, borderRadius:14, margin:"6px auto 16px", background:"color-mix(in oklab, var(--src-fx) 18%, transparent)",
              border:"1px solid color-mix(in oklab, var(--src-fx) 40%, transparent)", display:"flex", alignItems:"center", justifyContent:"center", color:"var(--src-fx)" }}>
              <I.check size={26} />
            </div>
            <div style={{ textAlign:"center", fontSize:14, fontWeight:650, marginBottom:3 }}>Export complete</div>
            <div style={{ textAlign:"center", fontSize:12, color:"var(--text-2)", marginBottom:18 }}>Your recomposition is ready.</div>
            <div style={{ display:"flex", alignItems:"center", gap:11, padding:"11px 12px", borderRadius:"var(--r-md)",
              background:"var(--bg-2)", border:"1px solid var(--line-2)" }}>
              <span style={{ width:36, height:36, borderRadius:8, background:"var(--accent-soft)", color:"var(--accent-text)",
                display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>{cfg.format==="video"?<I.film size={18}/>:<I.wave size={18}/>}</span>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:12.5, fontWeight:600, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>
                  Q3-Brand-Film_{dub?cfg.lang:"orig"}.{cfg.format==="video"?"mp4":"wav"}</div>
                <div className="mono" style={{ fontSize:10.5, color:"var(--text-2)" }}>{RC.fmt(total)} · {cfg.format==="video"?"1080p":"WAV 48k"} · {dub?langLabel+" dub":"original"}</div>
              </div>
            </div>
            <div style={{ display:"flex", gap:8, marginTop:14 }}>
              <Btn kind="primary" size="lg" icon={I.download} full>Download</Btn>
              <Tooltip label="Copy share link"><Btn kind="outline" size="lg" icon={I.link} /></Tooltip>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div style={{ padding:"15px 15px 30px" }}>
      <SectionLabel>Format</SectionLabel>
      <Seg value={cfg.format} onChange={v=>set({format:v})}
        options={[{value:"video",label:"Video",icon:I.film},{value:"audio",label:"Audio",icon:I.wave}]} />
      <div style={{ marginTop:11, display:"flex", flexDirection:"column", gap:9 }}>
        <Row label={cfg.format==="video"?"Resolution":"Sample rate"}>
          <div style={{ width:140 }}>
            <Select size="sm" full value={cfg.quality} onChange={v=>set({quality:v})}
              options={cfg.format==="video"
                ? [{value:"2160",label:"2160p · 4K"},{value:"1080",label:"1080p · HD"},{value:"720",label:"720p"}]
                : [{value:"48",label:"48 kHz · WAV"},{value:"44",label:"44.1 kHz · WAV"},{value:"mp3",label:"320k · MP3"}]} />
          </div>
        </Row>
        <Row label="Loudness target">
          <div style={{ width:140 }}>
            <Select size="sm" full value={cfg.loudness} onChange={v=>set({loudness:v})}
              options={[{value:"-14",label:"−14 LUFS · web"},{value:"-16",label:"−16 LUFS · podcast"},{value:"-23",label:"−23 LUFS · broadcast"}]} />
          </div>
        </Row>
        <Row label="Burn-in captions"><Toggle value={cfg.captions} onChange={v=>set({captions:v})} /></Row>
      </div>

      <div style={{ height:1, background:"var(--line)", margin:"16px 0" }} />
      <SectionLabel right={<Badge tone="accent"><I.sparkle size={11} /> AI</Badge>}>Translate &amp; dub</SectionLabel>
      <Row label="Language"><div style={{ width:160 }}><Select size="sm" full value={cfg.lang} onChange={v=>set({lang:v})} options={RC.LANGS} /></div></Row>
      {cfg.lang!=="none" && (
        <div style={{ marginTop:9 }}>
          <Row label="Voice dubbing" hint="clone original voices"><Toggle value={cfg.dub} onChange={v=>set({dub:v})} /></Row>
          {cfg.dub && (
            <div style={{ marginTop:9, background:"var(--bg-2)", border:"1px solid var(--line)", borderRadius:"var(--r-md)", padding:"9px 10px" }}>
              <div style={{ fontSize:10.5, fontWeight:700, letterSpacing:".06em", textTransform:"uppercase", color:"var(--text-2)", marginBottom:8 }}>Voice mapping</div>
              {Object.values(RC.SPEAKERS).map(sp=>(
                <div key={sp.id} style={{ display:"flex", alignItems:"center", gap:8, padding:"4px 0" }}>
                  <Avatar id={sp.id} size={22} />
                  <span style={{ fontSize:12, fontWeight:550, flex:1 }}>{sp.name}</span>
                  <I.chevR size={13} style={{ color:"var(--text-3)" }} />
                  <span style={{ display:"inline-flex", alignItems:"center", gap:5, fontSize:11.5, color:"var(--accent-text)", fontWeight:600 }}>
                    <I.sparkle size={12} /> Cloned · {langLabel.split(" ")[0]}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <div style={{ height:1, background:"var(--line)", margin:"16px 0" }} />
      <SectionLabel>Summary</SectionLabel>
      <div style={{ display:"flex", flexDirection:"column", gap:6, marginBottom:16 }}>
        {[["Duration", RC.fmt(total)],["Clips", `${items.length}`],["Tracks","3 · dialogue, bed, sfx"],
          ["Output", `${cfg.format==="video"?(cfg.quality==="2160"?"4K":cfg.quality+"p")+" MP4":"WAV "+cfg.quality+"k"}`],
          ["Audio", dub?`${langLabel} dub`:"original"]].map(([k,v])=>(
          <div key={k} style={{ display:"flex", justifyContent:"space-between", fontSize:12 }}>
            <span style={{ color:"var(--text-2)" }}>{k}</span>
            <span className="mono" style={{ color:"var(--text-1)", fontWeight:500 }}>{v}</span>
          </div>
        ))}
      </div>
      <Btn kind="primary" size="lg" icon={I.download} full onClick={()=>onExport("start")}>Export recomposition</Btn>
      <div style={{ marginTop:9, textAlign:"center", fontSize:11, color:"var(--text-3)" }}>Estimated render · {Math.ceil(total/8)} min on Pro</div>
    </div>
  );
}

window.ExportPanel = ExportPanel;
window.Studio = { Player, Script, Timeline };

/* spin keyframe */
const _spinStyle = document.createElement("style");
_spinStyle.textContent = "@keyframes spin{to{transform:rotate(360deg)}}";
document.head.appendChild(_spinStyle);
