/* ===================== Left rail + Source panel + Right panel ===================== */

/* ---------- Icon nav rail ---------- */
function LeftRail({ theme, onToggleTheme, nav, onNav, accent }){
  const items = [
    { id:"library", icon:I.library, label:"Library" },
    { id:"media",   icon:I.film,    label:"Media" },
    { id:"cuts",    icon:I.scissors,label:"Cuts" },
    { id:"studio",  icon:I.studio,  label:"Studio" },
    { id:"audio",   icon:I.sliders, label:"Audio mix" },
  ];
  return (
    <div style={{ width:"var(--rail)", flexShrink:0, background:"var(--bg-1)", borderRight:"1px solid var(--line)",
      display:"flex", flexDirection:"column", alignItems:"center", padding:"10px 0", gap:4, zIndex:30 }}>
      <Tooltip label="Recomposer" side="right">
        <div style={{ width:34, height:34, borderRadius:9, marginBottom:8, position:"relative",
          background:"linear-gradient(155deg, var(--accent), color-mix(in oklab, var(--accent) 55%, #000))",
          display:"flex", alignItems:"center", justifyContent:"center", boxShadow:"0 4px 12px -3px var(--accent-glow)" }}>
          <div style={{ display:"flex", alignItems:"flex-end", gap:1.5, height:14 }}>
            {[7,12,16,9,13].map((h,i)=><span key={i} style={{ width:1.8, height:h, borderRadius:99, background:"var(--accent-ink)", opacity: .65+i*0.07 }} />)}
          </div>
        </div>
      </Tooltip>
      {items.map(it=>{
        const on = nav===it.id;
        return (
          <Tooltip key={it.id} label={it.label} side="right">
            <button className="tx ring" onClick={()=>onNav(it.id)}
              style={{ width:40, height:38, borderRadius:9, border:"none", cursor:"pointer", position:"relative",
                display:"flex", alignItems:"center", justifyContent:"center",
                background: on?"var(--accent-soft)":"transparent", color: on?"var(--accent-text)":"var(--text-2)" }}
              onMouseEnter={e=>{ if(!on) e.currentTarget.style.background="var(--hover)"; }}
              onMouseLeave={e=>{ if(!on) e.currentTarget.style.background="transparent"; }}>
              {on && <span style={{ position:"absolute", left:-10, top:"50%", transform:"translateY(-50%)",
                width:3, height:18, borderRadius:99, background:"var(--accent)" }} />}
              <it.icon size={19} />
            </button>
          </Tooltip>
        );
      })}
      <div style={{ flex:1 }} />
      <Tooltip label={theme==="dark"?"Light theme":"Dark theme"} side="right">
        <button className="tx ring" onClick={onToggleTheme}
          style={{ width:40, height:38, borderRadius:9, border:"none", cursor:"pointer", color:"var(--text-2)",
            background:"transparent", display:"flex", alignItems:"center", justifyContent:"center" }}
          onMouseEnter={e=>e.currentTarget.style.background="var(--hover)"}
          onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
          {theme==="dark"? <I.sun size={18} /> : <I.moon size={18} />}
        </button>
      </Tooltip>
      <Tooltip label="Settings" side="right">
        <button className="tx ring" onClick={()=>onNav("settings")}
          style={{ width:40, height:38, borderRadius:9, border:"none", cursor:"pointer", color:"var(--text-2)",
            background:"transparent", display:"flex", alignItems:"center", justifyContent:"center" }}
          onMouseEnter={e=>e.currentTarget.style.background="var(--hover)"}
          onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
          <I.settings size={18} />
        </button>
      </Tooltip>
      <div style={{ marginTop:4 }}><Avatar id="maya" size={28} /></div>
    </div>
  );
}

/* ---------- Source clips panel ---------- */
function SourcePanel({ onAdd, collapsed, onCollapse }){
  const [q, setQ] = useState("");
  const [spk, setSpk] = useState("all");
  const clips = RC.SOURCE_CLIPS.filter(c=>{
    if(spk!=="all" && c.spk!==spk) return false;
    if(q && !c.text.toLowerCase().includes(q.toLowerCase()) && !RC.SPEAKERS[c.spk].name.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });
  const speakers = [{id:"all",name:"All"}, ...Object.values(RC.SPEAKERS)];
  return (
    <div style={{ width:"var(--src-w)", flexShrink:0, background:"var(--bg-1)", borderRight:"1px solid var(--line)",
      display:"flex", flexDirection:"column", minHeight:0 }}>
      <div style={{ padding:"13px 14px 10px", borderBottom:"1px solid var(--line)" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:11 }}>
          <div style={{ display:"flex", alignItems:"center", gap:7 }}>
            <span style={{ fontSize:13, fontWeight:650 }}>Source clips</span>
            <Badge tone="mono">{RC.SOURCE_CLIPS.length}</Badge>
          </div>
          <Tooltip label="Import media"><Btn size="iconSm" kind="ghost"><I.plus size={16} /></Btn></Tooltip>
        </div>
        <div style={{ position:"relative", marginBottom:9 }}>
          <span style={{ position:"absolute", left:9, top:"50%", transform:"translateY(-50%)", color:"var(--text-2)" }}><I.search size={14} /></span>
          <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search transcript\u2026" className="tx ring"
            style={{ width:"100%", height:30, padding:"0 10px 0 30px", background:"var(--bg-3)", color:"var(--text)",
              border:"1px solid var(--line)", borderRadius:"var(--r-md)", fontSize:12, fontFamily:"var(--font)", outline:"none" }} />
        </div>
        <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
          {speakers.map(s=>{
            const on = spk===s.id;
            return <button key={s.id} className="tx" onClick={()=>setSpk(s.id)}
              style={{ display:"inline-flex", alignItems:"center", gap:5, height:23, padding:"0 8px", borderRadius:99, cursor:"pointer",
                fontSize:11, fontWeight:550, fontFamily:"var(--font)",
                border:"1px solid", borderColor: on?"var(--accent-line)":"var(--line)",
                background: on?"var(--accent-soft)":"transparent", color: on?"var(--accent-text)":"var(--text-1)" }}>
              {s.hue && <span style={{ width:6, height:6, borderRadius:99, background:s.hue }} />}
              {s.id==="all"?"All":s.name.split(" ")[0]}
            </button>;
          })}
        </div>
      </div>
      <div style={{ flex:1, overflowY:"auto", padding:"8px 8px 14px" }}>
        {clips.length===0 && <div style={{ padding:"30px 10px", textAlign:"center", color:"var(--text-2)", fontSize:12 }}>No matching clips</div>}
        <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
          {clips.map(c=>{
            const sp = RC.SPEAKERS[c.spk];
            return (
              <div key={c.id} className="tx srcclip" draggable
                style={{ padding:"9px 10px", borderRadius:"var(--r-md)", border:"1px solid var(--line)",
                  background:"var(--bg-2)", cursor:"grab", position:"relative" }}
                onMouseEnter={e=>{ e.currentTarget.style.borderColor="var(--line-2)"; e.currentTarget.querySelector(".addbtn").style.opacity=1; }}
                onMouseLeave={e=>{ e.currentTarget.style.borderColor="var(--line)"; e.currentTarget.querySelector(".addbtn").style.opacity=0; }}>
                <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:6 }}>
                  <SrcChip id={c.spk} mini />
                  <span className="mono" style={{ fontSize:10, color:"var(--text-2)" }}>{c.dur.toFixed(1)}s</span>
                </div>
                <div style={{ fontSize:11.5, color:"var(--text-1)", lineHeight:1.4, marginBottom:7,
                  display:"-webkit-box", WebkitLineClamp:2, WebkitBoxOrient:"vertical", overflow:"hidden" }}>{c.text}</div>
                <Waveform seed={c.id} height={16} barW={1.6} color="color-mix(in oklab, var(--text-2) 55%, transparent)" />
                <button className="addbtn tx" onClick={()=>onAdd(c)}
                  style={{ position:"absolute", top:8, right:8, opacity:0, width:22, height:22, borderRadius:6,
                    border:"1px solid var(--accent-line)", background:"var(--accent-soft)", color:"var(--accent-text)",
                    cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
                  <I.plus size={14} />
                </button>
              </div>
            );
          })}
        </div>
      </div>
      <div style={{ padding:"9px 12px", borderTop:"1px solid var(--line)", display:"flex", alignItems:"center",
        gap:7, color:"var(--text-2)", fontSize:11 }}>
        <I.drag size={13} /> Drag a clip into the script to insert
      </div>
    </div>
  );
}

/* ---------- Right: Inspector + Export ---------- */
function RightPanel(props){
  const { tab, setTab } = props;
  return (
    <div style={{ width:"var(--insp-w)", flexShrink:0, background:"var(--bg-1)", borderLeft:"1px solid var(--line)",
      display:"flex", flexDirection:"column", minHeight:0 }}>
      <div style={{ display:"flex", padding:"10px 12px 0", gap:2, borderBottom:"1px solid var(--line)" }}>
        {[{id:"inspect",label:"Inspector",icon:I.sliders},{id:"export",label:"Export",icon:I.download}].map(t=>{
          const on = tab===t.id;
          return (
            <button key={t.id} className="tx ring" onClick={()=>setTab(t.id)}
              style={{ display:"flex", alignItems:"center", gap:6, padding:"0 12px 11px", border:"none", cursor:"pointer",
                background:"transparent", fontFamily:"var(--font)", fontSize:12.5, fontWeight:600,
                color: on?"var(--text)":"var(--text-2)", position:"relative", marginBottom:-1 }}>
              <t.icon size={15} />{t.label}
              {on && <span style={{ position:"absolute", left:0, right:0, bottom:0, height:2, borderRadius:99, background:"var(--accent)" }} />}
            </button>
          );
        })}
      </div>
      <div style={{ flex:1, overflowY:"auto" }}>
        {tab==="inspect" ? <Inspector {...props} /> : React.createElement(window.ExportPanel, props)}
      </div>
    </div>
  );
}

/* ---------- Inspector ---------- */
function Inspector({ cut, idx, total, onPatch, onRemove, bed, onBedPatch, overlays }){
  if(!cut){
    return <div style={{ padding:"60px 24px", textAlign:"center", color:"var(--text-2)" }}>
      <div style={{ width:42, height:42, margin:"0 auto 14px", borderRadius:11, background:"var(--bg-3)",
        display:"flex", alignItems:"center", justifyContent:"center", color:"var(--text-3)" }}><I.sliders size={20} /></div>
      <div style={{ fontSize:13, fontWeight:600, color:"var(--text-1)", marginBottom:4 }}>Nothing selected</div>
      <div style={{ fontSize:12, lineHeight:1.5 }}>Select a clip in the script or timeline to edit its trim, gain and transitions.</div>
    </div>;
  }
  const sp = RC.SPEAKERS[cut.spk];
  const src = RC.SOURCES[sp.src];
  const Pill = ({label, children})=>(
    <div style={{ flex:1, background:"var(--bg-3)", border:"1px solid var(--line)", borderRadius:"var(--r-md)", padding:"7px 9px" }}>
      <div style={{ fontSize:9.5, fontWeight:700, letterSpacing:".07em", textTransform:"uppercase", color:"var(--text-2)", marginBottom:3 }}>{label}</div>
      <div className="mono" style={{ fontSize:12.5, color:"var(--text)", fontWeight:500 }}>{children}</div>
    </div>
  );
  return (
    <div style={{ padding:"14px 14px 28px" }}>
      {/* header */}
      <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:13 }}>
        <Avatar id={cut.spk} size={36} />
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:"flex", alignItems:"center", gap:7 }}>
            <span style={{ fontSize:13.5, fontWeight:650 }}>{sp.name}</span>
            <Badge tone="accent">Clip {String(idx+1).padStart(2,"0")}</Badge>
          </div>
          <div style={{ fontSize:11, color:"var(--text-2)", marginTop:1, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>
            {sp.role} · <span className="mono">{src.short}</span>
          </div>
        </div>
        <Tooltip label="Remove clip" side="left"><Btn size="icon" kind="danger" onClick={onRemove}><I.trash size={16} /></Btn></Tooltip>
      </div>

      {/* transcript preview */}
      <div style={{ background:"var(--bg-2)", border:"1px solid var(--line)", borderRadius:"var(--r-md)", padding:"10px 11px", marginBottom:14 }}>
        <div style={{ fontSize:12.5, lineHeight:1.5, color:"var(--text-1)", fontStyle:"italic" }}>\u201c{cut.text}\u201d</div>
        <div style={{ marginTop:9 }}><Waveform seed={cut.id} height={22} barW={2} /></div>
      </div>

      {/* trim */}
      <SectionLabel>Trim · source</SectionLabel>
      <div style={{ display:"flex", gap:7, marginBottom:8 }}>
        <Pill label="In">{RC.fmt(cut.srcIn)}</Pill>
        <Pill label="Out">{RC.fmt(cut.srcIn+cut.dur)}</Pill>
        <Pill label="Length">{cut.dur.toFixed(1)}s</Pill>
      </div>
      <div style={{ marginBottom:18 }}>
        <Row label="Playback speed" hint="×">
          <span className="mono" style={{ fontSize:11.5, color:"var(--text-1)", width:34, textAlign:"right" }}>{(cut.speed||1).toFixed(2)}</span>
        </Row>
        <Slider value={cut.speed||1} min={0.5} max={2} step={0.05} marks={[1]} onChange={v=>onPatch({speed:v})} />
      </div>

      {/* levels */}
      <SectionLabel>Levels</SectionLabel>
      <div style={{ marginBottom:13 }}>
        <Row label="Gain">
          <span className="mono" style={{ fontSize:11.5, color: cut.gain===0?"var(--text-2)":"var(--accent-text)", width:48, textAlign:"right" }}>
            {cut.gain>0?"+":""}{cut.gain.toFixed(1)} dB</span>
        </Row>
        <Slider value={cut.gain} min={-24} max={6} step={0.5} marks={[0]} onChange={v=>onPatch({gain:v})} />
      </div>
      <div style={{ display:"flex", gap:14, marginBottom:13 }}>
        <div style={{ flex:1 }}>
          <Row label="Fade in"><span className="mono" style={{ fontSize:11, color:"var(--text-2)" }}>{cut.fadeIn.toFixed(1)}s</span></Row>
          <Slider value={cut.fadeIn} min={0} max={3} step={0.1} onChange={v=>onPatch({fadeIn:v})} />
        </div>
        <div style={{ flex:1 }}>
          <Row label="Fade out"><span className="mono" style={{ fontSize:11, color:"var(--text-2)" }}>{cut.fadeOut.toFixed(1)}s</span></Row>
          <Slider value={cut.fadeOut} min={0} max={3} step={0.1} onChange={v=>onPatch({fadeOut:v})} />
        </div>
      </div>
      <Row label="Normalize to −16 LUFS">
        <Toggle value={!!cut.normalize} onChange={v=>onPatch({normalize:v})} />
      </Row>

      {/* transition */}
      <div style={{ height:1, background:"var(--line)", margin:"15px 0 16px" }} />
      <SectionLabel>Join to next clip</SectionLabel>
      {cut.trans.type==="end" ? (
        <div style={{ fontSize:12, color:"var(--text-2)", padding:"4px 2px" }}>This is the final clip in the recomposition.</div>
      ) : (
        <>
          <Seg value={cut.trans.type} onChange={v=>onPatch({trans:{...cut.trans, type:v, dur: v==="cut"?0:(cut.trans.dur||0.35)}})}
            options={[{value:"cut",label:"Hard cut"},{value:"crossfade",label:"Crossfade"},{value:"gap",label:"Gap"}]} />
          {cut.trans.type!=="cut" && (
            <div style={{ marginTop:11 }}>
              <Row label={cut.trans.type==="crossfade"?"Crossfade length":"Silence length"}>
                <span className="mono" style={{ fontSize:11, color:"var(--text-2)" }}>{cut.trans.dur.toFixed(2)}s</span>
              </Row>
              <Slider value={cut.trans.dur} min={0.1} max={2} step={0.05} onChange={v=>onPatch({trans:{...cut.trans, dur:v}})} />
            </div>
          )}
        </>
      )}

      {/* master / tracks */}
      <div style={{ height:1, background:"var(--line)", margin:"18px 0 16px" }} />
      <SectionLabel right={<Badge tone="mono">{1+overlays.length} tracks</Badge>}>Beds &amp; overlays</SectionLabel>
      <div style={{ display:"flex", alignItems:"center", gap:10, padding:"9px 10px", borderRadius:"var(--r-md)",
        background:"var(--bg-2)", border:"1px solid var(--line)", marginBottom:7 }}>
        <span style={{ width:26, height:26, borderRadius:7, background:"color-mix(in oklab, var(--src-bed) 22%, transparent)",
          color:"var(--src-bed)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}><I.music size={15} /></span>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:12, fontWeight:600, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{bed.name}</div>
          <div style={{ fontSize:10.5, color:"var(--text-2)" }}>{bed.meta}</div>
        </div>
        <span className="mono" style={{ fontSize:11, color:"var(--text-2)" }}>{bed.gain} dB</span>
      </div>
      <Row label="Duck under speech" hint="−9 dB"><Toggle value={bed.duck} onChange={v=>onBedPatch({duck:v})} /></Row>
      {overlays.map(o=>(
        <div key={o.id} style={{ display:"flex", alignItems:"center", gap:10, padding:"8px 10px", borderRadius:"var(--r-md)",
          background:"var(--bg-2)", border:"1px solid var(--line)", marginTop:7 }}>
          <span style={{ width:26, height:26, borderRadius:7, background:"color-mix(in oklab, var(--src-fx) 20%, transparent)",
            color:"var(--src-fx)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}><I.wave size={15} /></span>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:12, fontWeight:600 }}>{o.name}</div>
            <div style={{ fontSize:10.5, color:"var(--text-2)" }}>{o.meta} · @{RC.fmtShort(o.start)}</div>
          </div>
          <span className="mono" style={{ fontSize:11, color:"var(--text-2)" }}>{o.gain} dB</span>
        </div>
      ))}
    </div>
  );
}

window.Panels = { LeftRail, SourcePanel, RightPanel };
window.ExportPanelHost = true; // ExportPanel defined in studio.jsx
